# Savings Offline Android APK

This repository builds an offline Android savings jar app.

## Build APK
1. Upload these repository files to a GitHub repository.
2. Open Actions → Build Android APK → Run workflow.
3. When the run completes, open its summary and download the `savings-offline-apk` artifact.
4. Extract the downloaded ZIP and install `app-debug.apk` on Android.

The APK app stores data locally on the device. It does not require internet permission. Internet is needed only for GitHub to build and deliver the APK.
