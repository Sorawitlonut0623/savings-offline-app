package com.example.savingsoffline

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Pine = Color(0xFF247A58)
private val Pale = Color(0xFFE7F3EC)
private val Ink = Color(0xFF17251E)
private val Muted = Color(0xFF718078)
private val Bg = Color(0xFFF5F8F5)
private val Orange = Color(0xFFE89A42)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SavingsApp(this) }
    }
}

data class JarData(val id: Long, val name: String, val target: Long, val note: String, val created: Long)
data class MoveData(val id: Long, val jarId: Long, val kind: String, val amount: Long, val memo: String, val time: Long)

private fun money(value: Long): String = NumberFormat.getNumberInstance(Locale("th", "TH")).format(value) + " บาท"
private fun dateText(time: Long): String = SimpleDateFormat("d MMM yyyy • HH:mm", Locale("th", "TH")).format(Date(time))

@Composable
fun SavingsApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("savings_offline", Context.MODE_PRIVATE) }
    val jars = remember { mutableStateListOf<JarData>().apply { addAll(readJars(prefs)) } }
    val moves = remember { mutableStateListOf<MoveData>().apply { addAll(readMoves(prefs)) } }
    var tab by remember { mutableIntStateOf(0) }
    var showJarDialog by remember { mutableStateOf(false) }
    var editingJar by remember { mutableStateOf<JarData?>(null) }
    var movingJar by remember { mutableStateOf<JarData?>(null) }
    var moveKind by remember { mutableStateOf("in") }
    var deleteJar by remember { mutableStateOf<JarData?>(null) }
    var selectedJar by remember { mutableStateOf<JarData?>(null) }

    fun saveAll() {
        val ja = JSONArray(); jars.forEach { ja.put(JSONObject().put("id", it.id).put("name", it.name).put("target", it.target).put("note", it.note).put("created", it.created)) }
        val ma = JSONArray(); moves.forEach { ma.put(JSONObject().put("id", it.id).put("jarId", it.jarId).put("kind", it.kind).put("amount", it.amount).put("memo", it.memo).put("time", it.time)) }
        prefs.edit().putString("jars", ja.toString()).putString("moves", ma.toString()).apply()
    }
    val total = jars.sumOf { jar -> moves.filter { it.jarId == jar.id }.sumOf { if (it.kind == "in") it.amount else -it.amount } }
    val monthMoves = moves.filter { SimpleDateFormat("yyyyMM", Locale.US).format(Date(it.time)) == SimpleDateFormat("yyyyMM", Locale.US).format(Date()) }
    val monthIn = monthMoves.filter { it.kind == "in" }.sumOf { it.amount }
    val monthOut = monthMoves.filter { it.kind == "out" }.sumOf { it.amount }

    MaterialTheme(colorScheme = lightColorScheme(primary = Pine, background = Bg, surface = Color.White, onBackground = Ink, onSurface = Ink)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0; selectedJar = null }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("ภาพรวม") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1; selectedJar = null }, icon = { Icon(Icons.Default.History, null) }, label = { Text("ประวัติ") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (selectedJar != null) {
                    JarDetailScreen(selectedJar!!, moves.filter { it.jarId == selectedJar!!.id }.sortedByDescending { it.time },
                        onBack = { selectedJar = null },
                        onAdd = { movingJar = selectedJar; moveKind = "in" },
                        onOut = { movingJar = selectedJar; moveKind = "out" },
                        onEdit = { editingJar = selectedJar; showJarDialog = true },
                        onDelete = { deleteJar = selectedJar })
                } else if (tab == 0) {
                    DashboardScreen(total, jars, moves, monthIn, monthOut,
                        onAddJar = { editingJar = null; showJarDialog = true },
                        onSelect = { selectedJar = it },
                        onDeposit = { movingJar = it; moveKind = "in" },
                        onWithdraw = { movingJar = it; moveKind = "out" })
                } else {
                    HistoryScreen(moves.sortedByDescending { it.time }, jars)
                }
            }
        }
    }

    if (showJarDialog) JarEditorDialog(editingJar, onDismiss = { showJarDialog = false }, onSave = { name, target, note ->
        val old = editingJar
        if (old == null) jars.add(JarData(System.currentTimeMillis(), name, target, note, System.currentTimeMillis()))
        else { val i = jars.indexOfFirst { it.id == old.id }; if (i >= 0) jars[i] = old.copy(name = name, target = target, note = note) }
        saveAll(); showJarDialog = false
    })

    if (movingJar != null) MoveMoneyDialog(movingJar!!, moveKind, onDismiss = { movingJar = null }, onSave = { amount, memo ->
        val jar = movingJar!!
        val balance = moves.filter { it.jarId == jar.id }.sumOf { if (it.kind == "in") it.amount else -it.amount }
        if (moveKind == "out" && amount > balance) return@MoveMoneyDialog false
        moves.add(MoveData(System.currentTimeMillis(), jar.id, moveKind, amount, memo, System.currentTimeMillis()))
        saveAll(); movingJar = null; true
    })

    if (deleteJar != null) AlertDialog(onDismissRequest = { deleteJar = null }, title = { Text("ลบกระปุกนี้?") }, text = { Text("รายการเงินทั้งหมดในกระปุกนี้จะถูกลบด้วย") }, confirmButton = {
        TextButton(onClick = { val id = deleteJar!!.id; jars.removeAll { it.id == id }; moves.removeAll { it.jarId == id }; saveAll(); selectedJar = null; deleteJar = null }) { Text("ลบ", color = Color.Red) }
    }, dismissButton = { TextButton(onClick = { deleteJar = null }) { Text("ยกเลิก") } })
}

private fun readJars(p: android.content.SharedPreferences): List<JarData> = try {
    val a = JSONArray(p.getString("jars", "[]")); (0 until a.length()).map { val o = a.getJSONObject(it); JarData(o.getLong("id"), o.getString("name"), o.getLong("target"), o.optString("note"), o.getLong("created")) }
} catch (_: Exception) { emptyList() }
private fun readMoves(p: android.content.SharedPreferences): List<MoveData> = try {
    val a = JSONArray(p.getString("moves", "[]")); (0 until a.length()).map { val o = a.getJSONObject(it); MoveData(o.getLong("id"), o.getLong("jarId"), o.getString("kind"), o.getLong("amount"), o.optString("memo"), o.getLong("time")) }
} catch (_: Exception) { emptyList() }

@Composable
fun DashboardScreen(total: Long, jars: List<JarData>, moves: List<MoveData>, monthIn: Long, monthOut: Long, onAddJar: () -> Unit, onSelect: (JarData) -> Unit, onDeposit: (JarData) -> Unit, onWithdraw: (JarData) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("กระปุกออมเงิน", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Pine), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("เงินออมทั้งหมด", color = Color.White.copy(alpha = .85f))
                    Text(money(total), color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    Text("ยอดรวมจากทุกกระปุก", color = Color.White.copy(alpha = .8f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("ใส่เดือนนี้", money(monthIn), Modifier.weight(1f), Pine)
                StatCard("ถอนเดือนนี้", money(monthOut), Modifier.weight(1f), Orange)
            }
        }
        item {
            MonthlyChartCard(moves)
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("กระปุกของฉัน", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = onAddJar) { Icon(Icons.Default.Add, null); Text("เพิ่มกระปุก") }
            }
        }
        if (jars.isEmpty()) item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Savings, null, tint = Pine, modifier = Modifier.size(42.dp))
                    Text("ยังไม่มีกระปุก", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 8.dp))
                    Text("ตั้งเป้าหมายแรก แล้วเริ่มออมทีละนิด", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    Button(onClick = onAddJar, modifier = Modifier.fillMaxWidth().padding(top = 14.dp)) { Text("สร้างกระปุกแรก") }
                }
            }
        }
        items(jars, key = { it.id }) { jar ->
            val balance = moves.filter { it.jarId == jar.id }.sumOf { if (it.kind == "in") it.amount else -it.amount }
            JarCard(jar, balance, onSelect, onDeposit, onWithdraw)
        }
        item { Text("ข้อมูลบันทึกอยู่ในโทรศัพท์เครื่องนี้เท่านั้น", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)) }
    }
}


@Composable
fun MonthlyChartCard(moves: List<MoveData>) {
    val months = (5 downTo 0).map { offset ->
        val cal = java.util.Calendar.getInstance().apply { add(java.util.Calendar.MONTH, -offset) }
        val key = SimpleDateFormat("yyyyMM", Locale.US).format(cal.time)
        val label = SimpleDateFormat("MMM", Locale("th", "TH")).format(cal.time)
        val value = moves.filter { it.kind == "in" && SimpleDateFormat("yyyyMM", Locale.US).format(Date(it.time)) == key }.sumOf { it.amount }
        label to value
    }
    val maxValue = months.maxOfOrNull { it.second }?.coerceAtLeast(1L) ?: 1L
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("เงินที่ออมในแต่ละเดือน", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().height(112.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                months.forEach { (label, value) ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom, modifier = Modifier.weight(1f).fillMaxHeight()) {
                        Text(if (value > 0) NumberFormat.getNumberInstance(Locale("th", "TH")).format(value) else "", fontSize = 9.sp, color = Muted, maxLines = 1)
                        Spacer(Modifier.height(4.dp))
                        Box(Modifier.width(22.dp).height((72f * value.toFloat() / maxValue.toFloat()).coerceAtLeast(if (value > 0) 4f else 2f).dp).background(if (value > 0) Pine else Pale, RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp)))
                        Spacer(Modifier.height(5.dp))
                        Text(label, fontSize = 10.sp, color = Muted)
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier, accent: Color) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) { Text(title, color = Muted, fontSize = 12.sp); Text(value, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = accent, modifier = Modifier.padding(top = 6.dp)) }
    }
}

@Composable
fun JarCard(jar: JarData, balance: Long, onSelect: (JarData) -> Unit, onDeposit: (JarData) -> Unit, onWithdraw: (JarData) -> Unit) {
    val progress = (balance.toFloat() / jar.target.coerceAtLeast(1)).coerceIn(0f, 1f)
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().clickable { onSelect(jar) }) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Pale, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Savings, null, tint = Pine) }
                Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(jar.name, fontWeight = FontWeight.Bold, fontSize = 16.sp); if (jar.note.isNotBlank()) Text(jar.note, color = Muted, fontSize = 12.sp) }
                Text("${(progress * 100).toInt()}%", color = Pine, fontWeight = FontWeight.Bold)
            }
            Text(money(balance), fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp))
            Text("เป้าหมาย ${money(jar.target)}", color = Muted, fontSize = 12.sp)
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(7.dp), color = Pine, trackColor = Pale)
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onDeposit(jar) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Add, null, Modifier.size(16.dp)); Text("เพิ่มเงิน") }
                OutlinedButton(onClick = { onWithdraw(jar) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.ArrowUpward, null, Modifier.size(16.dp)); Text("ถอนเงิน") }
            }
        }
    }
}

@Composable
fun JarDetailScreen(jar: JarData, history: List<MoveData>, onBack: () -> Unit, onAdd: () -> Unit, onOut: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val balance = history.sumOf { if (it.kind == "in") it.amount else -it.amount }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("‹  กลับ", color = Pine, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { onBack() }.padding(vertical = 8.dp))
        Text(jar.name, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text(jar.note, color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Pine), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(top = 18.dp)) {
            Column(Modifier.padding(20.dp)) { Text("ยอดเงินในกระปุก", color = Color.White.copy(alpha = .8f)); Text(money(balance), color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("เป้าหมาย ${money(jar.target)}", color = Color.White.copy(alpha = .8f)) }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onAdd, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Text("เพิ่มเงิน") }
            OutlinedButton(onClick = onOut, modifier = Modifier.weight(1f)) { Icon(Icons.Default.ArrowUpward, null); Text("ถอนเงิน") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = onEdit) { Icon(Icons.Default.Edit, null); Text("แก้ไข") }; TextButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = Color.Red); Text("ลบ", color = Color.Red) } }
        Text("ประวัติของกระปุกนี้", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(vertical = 8.dp))
        if (history.isEmpty()) Text("ยังไม่มีรายการ", color = Muted)
        LazyColumn { items(history, key = { it.id }) { MoveRow(it, jar.name) } }
    }
}

@Composable
fun HistoryScreen(moves: List<MoveData>, jars: List<JarData>) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("ประวัติรายการ", fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 14.dp))
        if (moves.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("ยังไม่มีประวัติการออม", color = Muted) }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) { items(moves, key = { it.id }) { move -> MoveRow(move, jars.firstOrNull { it.id == move.jarId }?.name ?: "กระปุกที่ถูกลบ") } }
    }
}

@Composable
fun MoveRow(move: MoveData, jarName: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).background(if (move.kind == "in") Pale else Color(0xFFFFF0E2), CircleShape), contentAlignment = Alignment.Center) { Icon(if (move.kind == "in") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = if (move.kind == "in") Pine else Orange) }
        Column(Modifier.weight(1f).padding(start = 10.dp)) { Text(jarName, fontWeight = FontWeight.SemiBold); Text((if (move.memo.isBlank()) if (move.kind == "in") "ฝากเงิน" else "ถอนเงิน" else move.memo) + " • " + dateText(move.time), color = Muted, fontSize = 11.sp) }
        Text((if (move.kind == "in") "+" else "−") + money(move.amount), color = if (move.kind == "in") Pine else Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
    HorizontalDivider(color = Color(0xFFE8EEE9))
}

@Composable
fun JarEditorDialog(jar: JarData?, onDismiss: () -> Unit, onSave: (String, Long, String) -> Unit) {
    var name by remember(jar) { mutableStateOf(jar?.name ?: "") }
    var target by remember(jar) { mutableStateOf(jar?.target?.toString() ?: "") }
    var note by remember(jar) { mutableStateOf(jar?.note ?: "") }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (jar == null) "สร้างกระปุกใหม่" else "แก้ไขกระปุก") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("ชื่อกระปุก") }, singleLine = true)
            OutlinedTextField(target, { target = it.filter(Char::isDigit) }, label = { Text("เป้าหมาย (บาท)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text("บันทึกเพิ่มเติม (ไม่บังคับ)") }, singleLine = true)
            if (error.isNotBlank()) Text(error, color = Color.Red, fontSize = 12.sp)
        }
    }, confirmButton = { TextButton(onClick = { val t = target.toLongOrNull(); if (name.isBlank()) error = "กรุณาใส่ชื่อกระปุก" else if (t == null || t < 1) error = "กรุณาใส่เป้าหมายเป็นตัวเลข" else onSave(name.trim(), t, note.trim()) }) { Text("บันทึก") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("ยกเลิก") } })
}

@Composable
fun MoveMoneyDialog(jar: JarData, kind: String, onDismiss: () -> Unit, onSave: (Long, String) -> Boolean) {
    var amount by remember { mutableStateOf("") }
    var memo by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (kind == "in") "เพิ่มเงิน • ${jar.name}" else "ถอนเงิน • ${jar.name}") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("จำนวนเงิน (บาท)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(memo, { memo = it }, label = { Text("หมายเหตุ (ไม่บังคับ)") }, singleLine = true)
            if (error.isNotBlank()) Text(error, color = Color.Red, fontSize = 12.sp)
        }
    }, confirmButton = { TextButton(onClick = { val a = amount.toLongOrNull(); if (a == null || a < 1) error = "กรุณาใส่จำนวนเงิน" else if (!onSave(a, memo.trim())) error = "ยอดเงินในกระปุกไม่เพียงพอ" }) { Text("ยืนยัน") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("ยกเลิก") } })
}
